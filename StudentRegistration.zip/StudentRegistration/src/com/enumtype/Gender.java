package com.enumtype;

public enum Gender {
	MALE, FEMALE;
}
