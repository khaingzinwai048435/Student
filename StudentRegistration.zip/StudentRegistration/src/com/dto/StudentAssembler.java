package com.dto;

import com.model.Student;

public class StudentAssembler {

	public Student convertDTOToModel(StudentDTO studentDTO) {
		Student student = null;
		if (studentDTO != null) {
			student = new Student();
			student.setId(studentDTO.getId());
			student.setAge(studentDTO.getAge());
			student.setAddress(studentDTO.getAddress());
			student.setDateOfBirth(studentDTO.getDateOfBirth());
			student.setGender(studentDTO.getGender());
			student.setName(studentDTO.getName());
			student.setCourse(studentDTO.getCourse());
		}
		return student;
	}

	public StudentDTO convertModelToDTO(Student student) {
		StudentDTO studentDTO = null;
		if (student != null) {
			studentDTO = new StudentDTO();
			studentDTO.setId(student.getId());
			studentDTO.setAge(student.getAge());
			studentDTO.setAddress(student.getAddress());
			studentDTO.setDateOfBirth(student.getDateOfBirth());
			studentDTO.setGender(student.getGender());
			studentDTO.setName(student.getName());
			studentDTO.setCourse(student.getCourse());
		}
		return studentDTO;
	}

}
