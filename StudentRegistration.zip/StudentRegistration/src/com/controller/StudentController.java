package com.controller;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.StudentDTO;
import com.enumtype.Gender;
import com.service.IStudentService;
import com.validator.StudentValidator;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.xml.JRXmlLoader;

@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	IStudentService studentService;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
		binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
		binder.setValidator(new StudentValidator());

	}

	@RequestMapping(value = "/insert", method = RequestMethod.GET)
	public ModelAndView insert(Model model) {
		model.addAttribute("studentDTO", new StudentDTO());
		return new ModelAndView("insert");
	}

	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public ModelAndView inserted(@ModelAttribute("studentDTO") @Validated StudentDTO studentDTO, BindingResult result,
			Model model) {
		if (result.hasErrors()) {
			model.addAttribute("studentDTO", studentDTO);
			return new ModelAndView("insert");
		}
		studentService.insertStudent(studentDTO);
		return new ModelAndView("redirect:list");
	}

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public ModelAndView update(@RequestParam("studentid") Long studentId, Model model) {
		StudentDTO studentDTO = studentService.findById(studentId);
		model.addAttribute("studentDTO", studentDTO);
		return new ModelAndView("update");
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updated(@ModelAttribute("studentDTO") @Validated StudentDTO studentDTO, BindingResult result,
			Model model) {
		if (result.hasErrors()) {
			model.addAttribute("studentDTO", studentDTO);
		}
		studentDTO = studentService.updateStudent(studentDTO);
		return new ModelAndView("redirect:list");
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam("studentid") Long studentId) {
		studentService.deleteStudent(studentId);
		return new ModelAndView("redirect:list");
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView studentList(Model model) {
		List<StudentDTO> studentDTOList = studentService.inquireStudentList();
		model.addAttribute("studentDTOList", studentDTOList);
		return new ModelAndView("student-list");
	}

	@RequestMapping(value = "pdf", method = RequestMethod.GET)
	public void print(@RequestParam("studentid") Long studentId, HttpServletResponse httpServletResponse,
			HttpSession session) {
		try {
			StudentDTO studentDTO = studentService.findById(studentId);
			List<Map<String, ?>> dataSource = new ArrayList<Map<String, ?>>();
			Map<String, Object> map = new HashMap<String, Object>();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String reportName = "Student Detail - " + simpleDateFormat.format(new Date());

			map.put("studentDTO", studentDTO);
			dataSource.add(map);
			this.printFile(null, dataSource, "student_detail.jrxml", reportName, httpServletResponse);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void printFile(Map<String, Object> param, List<Map<String, ?>> dataSource, String jrxmlName,
			String reportName, HttpServletResponse httpServletResponse) {
		ClassLoader classLoader = null;
		InputStream url = null;
		ServletOutputStream servletOutputStream = null;
		try {
			servletOutputStream = httpServletResponse.getOutputStream();
			JRDataSource jrDataSource = new JRBeanCollectionDataSource(dataSource);
			classLoader = getClass().getClassLoader();
			url = classLoader.getResourceAsStream(jrxmlName);

			JasperDesign jasperReportDesign = JRXmlLoader.load(url);
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperReportDesign);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, param, jrDataSource);

			// removeBlankPage
			for (Iterator<JRPrintPage> i = jasperPrint.getPages().iterator(); i.hasNext();) {
				JRPrintPage page = i.next();
				if (page.getElements().size() == 0)
					i.remove();
			}

			httpServletResponse.setHeader("Content-Disposition", "attachment; filename=\"" + reportName + ".pdf\"");
			JRExporter exporter = new JRPdfExporter();

			exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, servletOutputStream);
			exporter.exportReport();

			servletOutputStream.flush();
			servletOutputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
