package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtils {
	private static EntityManagerFactory emf;

	public static EntityManager getEntityManager() {
		if (emf == null) {
			emf = Persistence.createEntityManagerFactory("StudentRegistration");
		}
		return emf.createEntityManager();
	}

	/**
	 * close entity manager factory.
	 */
	public static void destroyedEntityManagerFactory() {
		if (emf != null) {
			emf.close();
		}
	}

}
