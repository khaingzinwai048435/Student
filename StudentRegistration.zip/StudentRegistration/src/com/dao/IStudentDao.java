package com.dao;

import java.util.List;

import com.model.Student;

public interface IStudentDao {
	public Student insertStudent(Student student);

	public Student updateStudent(Student student);

	public Student findById(Long studentId);

	public Student deleteStudent(Long studentId);

	public List<Student> inquireStudentList();
}
