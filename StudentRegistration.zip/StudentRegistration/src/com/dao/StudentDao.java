package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import com.model.Student;

public class StudentDao implements IStudentDao {

	@Override
	public Student insertStudent(Student student) {
		EntityManager entityManager = JPAUtils.getEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(student);
		entityManager.getTransaction().commit();
		entityManager.close();
		return student;
	}

	@Override
	public Student updateStudent(Student student) {
		EntityManager entitymanager = JPAUtils.getEntityManager();
		entitymanager.getTransaction().begin();
		Student stud = entitymanager.find(Student.class, student.getId());
		stud.setName(student.getName());
		stud.setAddress(student.getAddress());
		stud.setAge(student.getAge());
		stud.setCourse(student.getCourse());
		stud.setDateOfBirth(student.getDateOfBirth());
		student.setGender(student.getGender());
		stud = entitymanager.merge(stud);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		return stud;
	}

	@Override
	public Student findById(Long studentId) {
		EntityManager entitymanager = JPAUtils.getEntityManager();
		entitymanager.getTransaction().begin();
		Student result = entitymanager.find(Student.class, studentId);
		entitymanager.getTransaction().commit();
		entitymanager.close();
		return result;
	}

	@Override
	public Student deleteStudent(Long studentId) {
		EntityManager entitymanager = JPAUtils.getEntityManager();
		entitymanager.getTransaction().begin();
		Student result = entitymanager.find(Student.class, studentId);
		if (result != null) {
			entitymanager.remove(result);
		}

		entitymanager.getTransaction().commit();
		entitymanager.close();
		return result;
	}

	@Override
	public List<Student> inquireStudentList() {
		EntityManager entitymanager = JPAUtils.getEntityManager();
		entitymanager.getTransaction().begin();

		CriteriaBuilder cb = entitymanager.getCriteriaBuilder();
		CriteriaQuery<Student> cq = cb.createQuery(Student.class);
		Root<Student> root = cq.from(Student.class);
		cq.select(root);
		List<Student> students = entitymanager.createQuery(cq).getResultList();
		entitymanager.getTransaction().commit();
		entitymanager.close();
		return students;
	}

}
