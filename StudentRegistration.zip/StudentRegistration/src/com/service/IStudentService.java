package com.service;

import java.util.List;

import com.dto.StudentDTO;

public interface IStudentService {

	public StudentDTO insertStudent(StudentDTO studentDTO);

	public StudentDTO updateStudent(StudentDTO studentDTO);

	public StudentDTO findById(Long studentId);

	public StudentDTO deleteStudent(Long studentId);

	public List<StudentDTO> inquireStudentList();

}
