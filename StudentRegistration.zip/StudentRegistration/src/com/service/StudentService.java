package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dao.IStudentDao;
import com.dto.StudentAssembler;
import com.dto.StudentDTO;
import com.model.Student;

public class StudentService implements IStudentService {

	@Autowired
	private IStudentDao studentDao;

	@Override
	public StudentDTO insertStudent(StudentDTO studentDTO) {
		StudentAssembler studentAssembler = new StudentAssembler();
		Student student = studentAssembler.convertDTOToModel(studentDTO);
		studentDTO = studentAssembler.convertModelToDTO(studentDao.insertStudent(student));
		return studentDTO;
	}

	@Override
	public StudentDTO updateStudent(StudentDTO studentDTO) {
		StudentAssembler studentAssembler = new StudentAssembler();
		Student student = studentAssembler.convertDTOToModel(studentDTO);
		studentDTO = studentAssembler.convertModelToDTO(studentDao.updateStudent(student));
		return studentDTO;
	}

	@Override
	public StudentDTO findById(Long studentId) {
		StudentAssembler studentAssembler = new StudentAssembler();
		Student student = studentDao.findById(studentId);
		StudentDTO studentDTO = studentAssembler.convertModelToDTO(student);
		return studentDTO;
	}

	@Override
	public StudentDTO deleteStudent(Long studentId) {
		StudentAssembler studentAssembler = new StudentAssembler();
		Student student = studentDao.deleteStudent(studentId);
		StudentDTO studentDTO = studentAssembler.convertModelToDTO(student);
		return studentDTO;
	}

	@Override
	public List<StudentDTO> inquireStudentList() {
		StudentAssembler studentAssembler = new StudentAssembler();

		List<Student> students = studentDao.inquireStudentList();
		List<StudentDTO> studentDTOs = new ArrayList<>();

		if (students != null) {
			for (Student student : students) {

				StudentDTO studentDTO = studentAssembler.convertModelToDTO(student);
				studentDTOs.add(studentDTO);
			}
		}

		return studentDTOs;
	}

}
