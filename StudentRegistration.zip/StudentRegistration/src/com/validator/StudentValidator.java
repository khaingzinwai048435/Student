package com.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.dto.StudentDTO;

public class StudentValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return StudentDTO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		StudentDTO studentDTO = (StudentDTO) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "student.name.NotEmpty");
		if (studentDTO.getAge() == null || studentDTO.getAge().equals("")) {
			errors.rejectValue("age", "student.age.NotEmpty");
		}

	}

}
